#include "mini_os.h"

// Is initialized with zeros at startup, as it's placed in the BSS section
struct process_table ptable;
