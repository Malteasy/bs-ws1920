#ifndef MINI_OS_GLOBALS_H
#define MINI_OS_GLOBALS_H
extern struct process_table ptable;
#endif
