#ifndef MINI_OS_PUBLIC_API_H
#define MINI_OS_PUBLIC_API_H
#include <stddef.h>
struct signal;
#include "../mini_os/syscalls/syscalls.h"
#endif
